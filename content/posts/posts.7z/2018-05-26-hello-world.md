---
layout: page
title: Hello World
date: "2018-05-26"
summary: My First Blog post
---

Hi there,

So after spending some time thinking on using some other theme and make it(blog) look cool I accepted the fact that it will take some time to get hang of jekyll and stuff so I decided to get started with "blogging" without any fancy theme :(

Also I am really not sure what content I'll be presenting so theme doesn't matter but I can promise you this, whatever content I'll be putting up here it won't be anything special :)

Few Things I have in my minds for the blog are:

* Updates on my GSoC'18 project(Yup !! I got selected Thanks to [@dufferzafar](https://github.com/dufferzafar) and his fellow jamians)
* How to start a blog - I am having hard time understanding things so might not be able to give great content but whatever !!
* Flashing new ROM to android phone - I messed up my phone recently And will be flashing a new ROM(resurrection remix).

And about future , well A great man once said  - " The only thing we know about future is that it will be different ". so we'll see how different it will be.

P.S - The quote in the end isn't relevant in anyway but quotes always make things cool.

